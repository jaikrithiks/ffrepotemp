export const handleApiError = (error) => {
    if (error.response) {
      console.error("API Error:", error.response.data);
      return error.response.data.message || "An error occurred. Try again.";
    }
    console.error("Network Error:", error.message);
    return "Network error. Check your connection.";
  };
  