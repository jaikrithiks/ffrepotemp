export const logEvent = (message) => {
    console.log(`[LOG] ${new Date().toISOString()} - ${message}`);
  };
  
  export const logError = (error) => {
    console.error(`[ERROR] ${new Date().toISOString()} -`, error);
  };
  