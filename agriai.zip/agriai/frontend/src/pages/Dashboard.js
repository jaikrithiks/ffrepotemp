import React from "react";
function Dashboard() {
  return <h2>Dashboard</h2>;
}
export default Dashboard;

