import React, { useState } from "react";
import { loginUser, signupUser } from "../services/api";

const AuthForm = ({ type, onAuthSuccess }) => {
  const [formData, setFormData] = useState({ username: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = type === "login" ? await loginUser(formData) : await signupUser(formData);
      onAuthSuccess(response); // Callback function to handle authentication
    } catch (err) {
      setError("Authentication failed. Check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>{type === "login" ? "Login" : "Signup"}</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="username" placeholder="Username" onChange={handleChange} required />
        <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
        <button type="submit" disabled={loading}>{loading ? "Processing..." : type === "login" ? "Login" : "Signup"}</button>
        {error && <p style={{ color: "red" }}>{error}</p>}
      </form>
    </div>
  );
};

export default AuthForm;
