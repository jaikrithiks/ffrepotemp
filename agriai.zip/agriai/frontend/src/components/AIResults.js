import React from "react";

const AIResults = ({ result }) => {
  if (!result) return <p>No results available.</p>;

  return (
    <div>
      <h2>AI Analysis Results</h2>
      <p><strong>Prediction:</strong> {result.prediction}</p>
      <p><strong>Confidence:</strong> {result.confidence}%</p>
      {result.image_url && <img src={result.image_url} alt="Processed Result" style={{ maxWidth: "100%" }} />}
    </div>
  );
};

export default AIResults;
