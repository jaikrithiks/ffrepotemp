from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from urllib.parse import quote_plus

# Encode password to handle special characters
password = quote_plus("Bpsg@110")

# Corrected MySQL Database Configuration
DATABASE_URL = f"mysql+pymysql://root:{password}@localhost/FUTUREFARMS"

# Create Engine
engine = create_engine(DATABASE_URL, echo=True)

# Create Session
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base Class for Models (Only Define Once Here)
Base = declarative_base()
