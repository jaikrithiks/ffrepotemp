from fastapi import APIRouter, UploadFile, File
from services.ai_service import predict_pest

router = APIRouter()

@router.post("/pest-detection")
def detect_pest(image: UploadFile = File(...)):
    result = predict_pest(image)
    return result
