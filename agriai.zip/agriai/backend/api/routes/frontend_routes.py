from fastapi import APIRouter

router = APIRouter()

@router.get("/status")
def get_status():
    return {"message": "Backend is running successfully"}
