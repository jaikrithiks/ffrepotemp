from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database.database import SessionLocal
from models.farm_model import Farm
from services.auth_service import get_current_user

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/")
def create_farm(name: str, location: str, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    new_farm = Farm(name=name, location=location, owner_id=current_user.id)
    db.add(new_farm)
    db.commit()
    return new_farm

@router.get("/")
def get_farms(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    farms = db.query(Farm).filter(Farm.owner_id == current_user.id).all()
    return farms
