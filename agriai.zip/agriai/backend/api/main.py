from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from api.routes import (
    auth_routes, user_routes, farm_routes, ai_routes, image_upload_routes, frontend_routes
)
from services.database_service import init_db

app = FastAPI(title="AI-Powered Agricultural Decision Support System")

# Enable CORS for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database
init_db()

# Register Routes
app.include_router(auth_routes.router, prefix="/auth", tags=["Authentication"])
app.include_router(user_routes.router, prefix="/users", tags=["Users"])
app.include_router(farm_routes.router, prefix="/farms", tags=["Farms"])
app.include_router(ai_routes.router, prefix="/ai", tags=["AI Models"])
app.include_router(image_upload_routes.router, prefix="/images", tags=["Image Upload"])
app.include_router(frontend_routes.router, prefix="/frontend", tags=["Frontend"])

# Redirect root URL ("/") to Swagger UI ("/docs")
@app.get("/", include_in_schema=False)
def redirect_to_docs():
    return RedirectResponse(url="/docs")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
