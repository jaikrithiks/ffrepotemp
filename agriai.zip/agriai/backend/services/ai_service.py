from fastapi import UploadFile
import tensorflow as tf
import numpy as np
from PIL import Image
import io

def load_model():
    model = tf.keras.models.load_model("ai_module/models/pest_detection.h5")
    return model

def predict_pest(image: UploadFile):
    model = load_model()
    image_data = Image.open(io.BytesIO(image.file.read()))
    image_data = image_data.resize((224, 224))
    image_array = np.array(image_data) / 255.0
    image_array = np.expand_dims(image_array, axis=0)
    prediction = model.predict(image_array)
    return {"prediction": prediction.tolist()}
