import os

def deploy_to_cloud():
    os.system("docker build -t ai-agri-system .")
    os.system("docker run -p 8000:8000 ai-agri-system")
