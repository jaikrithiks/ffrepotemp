import os
from urllib.parse import quote_plus
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

# Securely Fetch Credentials from Environment Variables
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = quote_plus(os.getenv("DB_PASSWORD", "Bpsg@110"))  # Encode special characters
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_NAME = os.getenv("DB_NAME", "FUTUREFARMS")

# MySQL Database Configuration
DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}"

# Base Class for Models (Define Once)
Base = declarative_base()

class Database:
    """Database connection handler"""
    
    def __init__(self):
        try:
            self.engine = create_engine(DATABASE_URL, echo=True)
            self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
            print("✅ Database connection established successfully!")
        except Exception as e:
            print(f"❌ Error connecting to database: {e}")
            raise e

    def get_db(self):
        """Dependency function to get a database session"""
        db = self.SessionLocal()
        try:
            yield db
        finally:
            db.close()

# Create an instance of Database
db_instance = Database()

# ✅ Function to Fetch User by Username
def get_user_by_username(db: Session, username: str):
    """Fetch a user by their username"""
    from models.user_model import User  # 🔹 Move the import inside the function to avoid circular import
    return db.query(User).filter(User.username == username).first()

# ✅ Function to Create a New User
def create_user(db: Session, user_data):
    """Create a new user in the database"""
    from models.user_model import User  # 🔹 Move the import inside the function to avoid circular import
    new_user = User(**user_data)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

# ✅ Function to Initialize Database (Create Tables)
def init_db():
    """Initialize the database and create tables"""
    from models.user_model import Base  # Ensure Base is imported from your models
    Base.metadata.create_all(bind=db_instance.engine)
