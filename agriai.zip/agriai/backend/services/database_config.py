from sqlalchemy.ext.declarative import declarative_base

# Define Base class for ORM models
Base = declarative_base()
