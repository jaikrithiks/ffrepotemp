from services.ai_service import predict_pest
from services.image_processing_service import save_image

def process_uploaded_image(image):
    image_path = save_image(image)
    ai_result = predict_pest(image)
    return {"image_path": image_path, "ai_result": ai_result}
