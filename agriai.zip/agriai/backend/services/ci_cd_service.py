import os

def setup_ci_cd():
    os.system("git pull origin main")
    os.system("docker-compose up --build -d")
